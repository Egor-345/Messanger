import unittest
from typing import Dict, List
from models import TChessField, TChessMove, ESide, EChessmanType, TChessman
from pieces import Rook


class TestRook(unittest.TestCase):

    def setUp(self):
        self.all_pieces: List[TChessman] = []
        self.fields: Dict[str, TChessField] = {}

        for row in range(1, 9):
            for col_idx in range(8):
                col = chr(ord('A') + col_idx)
                field = TChessField(str(row), col)
                self.fields[f"{col}{row}"] = field

    def tearDown(self):
        for field in self.fields.values():
            field.setBusy(None)
        self.all_pieces.clear()

    def clear_all_fields(self):
        for field in self.fields.values():
            field.setBusy(None)
        self.all_pieces.clear()

    def test_rook_move_horizontal_right(self):
        self.clear_all_fields()
        field = self.fields["A1"]
        rook = Rook(ESide.WHITE, field)
        self.all_pieces.append(rook)

        move = TChessMove(field, self.fields["D1"])
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_rook_move_horizontal_left(self):
        self.clear_all_fields()
        field = self.fields["E4"]
        rook = Rook(ESide.WHITE, field)
        self.all_pieces.append(rook)

        move = TChessMove(field, self.fields["B4"])
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_rook_move_vertical_up(self):
        self.clear_all_fields()
        field = self.fields["A1"]
        rook = Rook(ESide.WHITE, field)
        self.all_pieces.append(rook)

        move = TChessMove(field, self.fields["A5"])
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_rook_move_vertical_down(self):
        self.clear_all_fields()
        field = self.fields["H6"]
        rook = Rook(ESide.WHITE, field)
        self.all_pieces.append(rook)

        move = TChessMove(field, self.fields["H2"])
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_rook_capture_enemy(self):
        self.clear_all_fields()
        from_field = self.fields["A1"]
        to_field = self.fields["A4"]

        rook = Rook(ESide.WHITE, from_field)
        self.all_pieces.append(rook)

        # Простая фигура-заглушка, не наследующая TChessman для простоты
        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        enemy = DummyPiece(ESide.BLACK)
        to_field.setBusy(enemy)

        move = TChessMove(from_field, to_field)
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_rook_move_to_edge(self):
        self.clear_all_fields()
        field = self.fields["D4"]
        rook = Rook(ESide.WHITE, field)
        self.all_pieces.append(rook)

        move = TChessMove(field, self.fields["H4"])
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_rook_move_max_distance(self):
        self.clear_all_fields()
        field = self.fields["A1"]
        rook = Rook(ESide.WHITE, field)
        self.all_pieces.append(rook)

        move = TChessMove(field, self.fields["H1"])
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_rook_move_diagonal(self):
        self.clear_all_fields()
        field = self.fields["D4"]
        rook = Rook(ESide.WHITE, field)
        self.all_pieces.append(rook)

        move = TChessMove(field, self.fields["F6"])
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertFalse(result)

    def test_rook_move_through_own_piece(self):
        self.clear_all_fields()
        from_field = self.fields["A1"]
        to_field = self.fields["A5"]

        rook = Rook(ESide.WHITE, from_field)
        self.all_pieces.append(rook)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        own = DummyPiece(ESide.WHITE)
        self.fields["A3"].setBusy(own)

        move = TChessMove(from_field, to_field)
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertFalse(result)

    def test_rook_move_through_enemy_piece(self):
        self.clear_all_fields()
        from_field = self.fields["A1"]
        to_field = self.fields["A5"]

        rook = Rook(ESide.WHITE, from_field)
        self.all_pieces.append(rook)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        enemy = DummyPiece(ESide.BLACK)
        self.fields["A3"].setBusy(enemy)

        move = TChessMove(from_field, to_field)
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertFalse(result)

    def test_rook_capture_own(self):
        self.clear_all_fields()
        from_field = self.fields["A1"]
        to_field = self.fields["A4"]

        rook = Rook(ESide.WHITE, from_field)
        self.all_pieces.append(rook)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        own = DummyPiece(ESide.WHITE)
        to_field.setBusy(own)

        move = TChessMove(from_field, to_field)
        result = rook.isValidMove(move, self.all_pieces, self.fields)
        self.assertFalse(result)

    def test_rook_move_out_of_board(self):
        with self.assertRaises(ValueError):
            TChessField("9", "I")

    def test_rook_initial_position(self):
        self.clear_all_fields()
        field = self.fields["A1"]
        rook = Rook(ESide.WHITE, field)

        self.assertEqual(rook.getPosition(), field)
        self.assertEqual(rook.getSide(), ESide.WHITE)
        self.assertEqual(rook.getType(), EChessmanType.ROOK)

    def test_rook_as_string_notation(self):
        from_field = self.fields["A1"]
        to_field = self.fields["A5"]
        move = TChessMove(from_field, to_field, EChessmanType.ROOK)
        self.assertEqual(move.asString(), "RA1-A5")

    def test_rook_go_to_position(self):
        self.clear_all_fields()
        from_field = self.fields["A1"]
        to_field = self.fields["A5"]
        rook = Rook(ESide.WHITE, from_field)

        self.assertEqual(rook.getPosition(), from_field)
        self.assertEqual(from_field.isBusy(), rook)

        rook.goToPosition(to_field)

        self.assertEqual(rook.getPosition(), to_field)
        self.assertEqual(to_field.isBusy(), rook)
        self.assertIsNone(from_field.isBusy())