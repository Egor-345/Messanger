from typing import List, Dict
from models import TChessman, EChessmanType, ESide, TChessField, TChessMove


class Bishop(TChessman):

    def __init__(self, side: ESide, field: TChessField):
        super().__init__(EChessmanType.BISHOP, field, side)

    def isValidMove(self, move: TChessMove, all_pieces: List[TChessman],
                    board: Dict[str, TChessField]) -> bool:
        from_field = move.getFrom()
        to_field = move.getTo()

        from_row = from_field.getRowInt()
        from_col = from_field.getColInt()
        to_row = to_field.getRowInt()
        to_col = to_field.getColInt()

        row_diff = abs(to_row - from_row)
        col_diff = abs(to_col - from_col)

        if row_diff != col_diff:
            return False

        target_piece = to_field.isBusy()
        if target_piece and target_piece.getSide() == self._side:
            return False

        row_step = 1 if to_row > from_row else -1
        col_step = 1 if to_col > from_col else -1

        steps = row_diff
        for i in range(1, steps):
            check_row = from_row + i * row_step
            check_col = from_col + i * col_step
            col_letter = chr(ord('A') + check_col - 1)
            key = f"{col_letter}{check_row}"
            check_field = board.get(key)
            if check_field and check_field.isBusy():
                return False

        return True