import unittest
from typing import Dict, List
from models import TChessField, TChessMove, ESide, TChessman
from pieces import Rook, Bishop


class TestCaptureScenarios(unittest.TestCase):

    def setUp(self):
        self.fields: Dict[str, TChessField] = {}
        self.all_pieces: List[TChessman] = []

        for row in range(1, 9):
            for col_idx in range(8):
                col = chr(ord('A') + col_idx)
                field = TChessField(str(row), col)
                self.fields[f"{col}{row}"] = field

    def tearDown(self):
        for field in self.fields.values():
            field.setBusy(None)
        self.all_pieces.clear()

    def clear_all_fields(self):
        for field in self.fields.values():
            field.setBusy(None)
        self.all_pieces.clear()

    def test_rook_capture_scenario_multiple_enemies(self):
        self.clear_all_fields()

        rook = Rook(ESide.WHITE, self.fields["A1"])
        self.all_pieces.append(rook)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        enemy1 = DummyPiece(ESide.BLACK)
        enemy2 = DummyPiece(ESide.BLACK)

        self.fields["A3"].setBusy(enemy1)
        self.fields["A5"].setBusy(enemy2)

        move1 = TChessMove(self.fields["A1"], self.fields["A3"])
        result1 = rook.isValidMove(move1, self.all_pieces, self.fields)

        move2 = TChessMove(self.fields["A1"], self.fields["A5"])
        result2 = rook.isValidMove(move2, self.all_pieces, self.fields)

        self.assertTrue(result1)
        self.assertFalse(result2)

    def test_bishop_capture_scenario_multiple_enemies(self):
        self.clear_all_fields()

        bishop = Bishop(ESide.WHITE, self.fields["C1"])
        self.all_pieces.append(bishop)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        enemy1 = DummyPiece(ESide.BLACK)
        enemy2 = DummyPiece(ESide.BLACK)

        self.fields["F4"].setBusy(enemy1)
        self.fields["H6"].setBusy(enemy2)

        move1 = TChessMove(self.fields["C1"], self.fields["F4"])
        result1 = bishop.isValidMove(move1, self.all_pieces, self.fields)

        move2 = TChessMove(self.fields["C1"], self.fields["H6"])
        result2 = bishop.isValidMove(move2, self.all_pieces, self.fields)

        self.assertTrue(result1)
        self.assertFalse(result2)

    def test_rook_capture_different_directions(self):
        self.clear_all_fields()

        rook = Rook(ESide.WHITE, self.fields["D4"])
        self.all_pieces.append(rook)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        enemy_up = DummyPiece(ESide.BLACK)
        enemy_right = DummyPiece(ESide.BLACK)

        self.fields["D6"].setBusy(enemy_up)
        self.fields["F4"].setBusy(enemy_right)

        move_up = TChessMove(self.fields["D4"], self.fields["D6"])
        result_up = rook.isValidMove(move_up, self.all_pieces, self.fields)

        move_right = TChessMove(self.fields["D4"], self.fields["F4"])
        result_right = rook.isValidMove(move_right, self.all_pieces,
                                        self.fields)

        self.assertTrue(result_up)
        self.assertTrue(result_right)

    def test_bishop_capture_different_directions(self):
        self.clear_all_fields()

        bishop = Bishop(ESide.WHITE, self.fields["D4"])
        self.all_pieces.append(bishop)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        enemy_up_right = DummyPiece(ESide.BLACK)
        enemy_down_left = DummyPiece(ESide.BLACK)

        self.fields["F6"].setBusy(enemy_up_right)
        self.fields["B2"].setBusy(enemy_down_left)

        move_up_right = TChessMove(self.fields["D4"], self.fields["F6"])
        result_up_right = bishop.isValidMove(move_up_right, self.all_pieces,
                                             self.fields)

        move_down_left = TChessMove(self.fields["D4"], self.fields["B2"])
        result_down_left = bishop.isValidMove(move_down_left, self.all_pieces,
                                              self.fields)

        self.assertTrue(result_up_right)
        self.assertTrue(result_down_left)