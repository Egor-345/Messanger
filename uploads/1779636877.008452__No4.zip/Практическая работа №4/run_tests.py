#!/usr/bin/env python3

import unittest
import sys


def run_all_tests():
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    from tests.test_rook import TestRook
    from tests.test_bishop import TestBishop
    from tests.test_captures import TestCaptureScenarios

    suite.addTests(loader.loadTestsFromTestCase(TestRook))
    suite.addTests(loader.loadTestsFromTestCase(TestBishop))
    suite.addTests(loader.loadTestsFromTestCase(TestCaptureScenarios))

    runner = unittest.TextTestRunner(verbosity=2, stream=sys.stdout)
    result = runner.run(suite)

    print("\n" + "=" * 70)
    print("РЕЗУЛЬТАТЫ ВЫПОЛНЕНИЯ ТЕСТОВ")
    print("=" * 70)
    print(f"  Всего тестов:     {result.testsRun}")
    print(
        f"  Успешно:          {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"  Неудачно:         {len(result.failures)}")
    print(f"  Ошибок:           {len(result.errors)}")
    print(
        f"  Процент успеха:   {(result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100:.1f}%")
    print("=" * 70)

    return result


if __name__ == "__main__":
    result = run_all_tests()
    sys.exit(0 if result.wasSuccessful() else 1)