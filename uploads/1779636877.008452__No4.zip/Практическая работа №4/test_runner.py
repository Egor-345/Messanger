"""
Альтернативный запуск тестов с использованием unittest discovery
"""

import unittest
import sys


def run_with_discovery():
    """Запуск тестов через автоматическое обнаружение"""

    loader = unittest.TestLoader()
    suite = loader.discover(start_dir='tests', pattern='test_*.py')

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "=" * 60)
    print(f"Всего тестов: {result.testsRun}")
    print(
        f"Успешно: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f="=" * 60)

    return result


if __name__ == "__main__":
    run_with_discovery()