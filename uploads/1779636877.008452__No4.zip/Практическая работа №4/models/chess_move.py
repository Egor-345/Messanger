"""Класс, представляющий шахматный ход"""

from typing import Optional
from .enums import EChessmanType
from .chess_field import TChessField


class TChessMove:
    """Класс, представляющий шахматный ход"""

    def __init__(self, from_field: TChessField, to_field: TChessField,
                 piece_type: Optional[EChessmanType] = None):
        self._from = from_field
        self._to = to_field
        self._piece_type = piece_type

    def getFrom(self) -> TChessField:
        return self._from

    def getTo(self) -> TChessField:
        return self._to

    def getPieceType(self) -> Optional[EChessmanType]:
        return self._piece_type

    def asString(self) -> str:
        """
        Возвращает описание хода в виде строки в шахматной нотации
        """
        if self._piece_type:
            prefix = self._piece_type.value
            return f"{prefix}{self._from}-{self._to}"
        return f"{self._from}-{self._to}"

    def __str__(self) -> str:
        return self.asString()