from abc import ABC, abstractmethod
from typing import List, Dict, Optional
from .enums import EChessmanType, ESide
from .chess_field import TChessField
from .chess_move import TChessMove


class TChessman(ABC):

    def __init__(self, piece_type: EChessmanType, field: TChessField, side: ESide):
        self._type = piece_type
        self._position = field
        self._side = side
        field.setBusy(self)

    def getPosition(self) -> TChessField:
        return self._position

    def getSide(self) -> ESide:
        return self._side

    def getType(self) -> EChessmanType:
        return self._type

    def setPosition(self, field: TChessField):
        if self._position:
            self._position.setBusy(None)
        self._position = field
        field.setBusy(self)

    @abstractmethod
    def isValidMove(self, move: TChessMove, all_pieces: List['TChessman'], board: Dict[str, 'TChessField']) -> bool:
        pass

    def goToPosition(self, new_position: TChessField) -> bool:
        self.setPosition(new_position)
        return True

    def __str__(self) -> str:
        return f"{self._side.value}_{self._type.value}_{self._position}"