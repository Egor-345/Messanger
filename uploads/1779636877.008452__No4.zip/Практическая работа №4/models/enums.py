"""Перечисления для шахматной программы"""

from enum import Enum


class EChessmanType(Enum):
    """Типы шахматных фигур"""
    ROOK = "R"
    BISHOP = "B"
    KNIGHT = "N"
    QUEEN = "Q"
    KING = "K"
    PAWN = "P"


class ESide(Enum):
    """Сторона: белые или черные"""
    WHITE = "white"
    BLACK = "black"