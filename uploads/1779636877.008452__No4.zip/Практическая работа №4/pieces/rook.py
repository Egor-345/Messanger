from typing import List, Dict
from models import TChessman, EChessmanType, ESide, TChessField, TChessMove


class Rook(TChessman):

    def __init__(self, side: ESide, field: TChessField):
        super().__init__(EChessmanType.ROOK, field, side)

    def isValidMove(self, move: TChessMove, all_pieces: List[TChessman],
                    board: Dict[str, TChessField]) -> bool:
        from_field = move.getFrom()
        to_field = move.getTo()

        from_row = from_field.getRowInt()
        from_col = from_field.getColInt()
        to_row = to_field.getRowInt()
        to_col = to_field.getColInt()

        if from_row != to_row and from_col != to_col:
            return False

        target_piece = to_field.isBusy()
        if target_piece and target_piece.getSide() == self._side:
            return False

        if from_row == to_row:
            step = 1 if to_col > from_col else -1
            for col in range(from_col + step, to_col, step):
                col_letter = chr(ord('A') + col - 1)
                key = f"{col_letter}{from_row}"
                check_field = board.get(key)
                if check_field and check_field.isBusy():
                    return False
        else:
            step = 1 if to_row > from_row else -1
            for row in range(from_row + step, to_row, step):
                col_letter = chr(ord('A') + from_col - 1)
                key = f"{col_letter}{row}"
                check_field = board.get(key)
                if check_field and check_field.isBusy():
                    return False

        return True