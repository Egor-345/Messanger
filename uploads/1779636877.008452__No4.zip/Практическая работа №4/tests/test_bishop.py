import unittest
from typing import Dict, List
from models import TChessField, TChessMove, ESide, EChessmanType, TChessman
from pieces import Bishop


class TestBishop(unittest.TestCase):

    def setUp(self):
        self.all_pieces: List[TChessman] = []
        self.fields: Dict[str, TChessField] = {}

        for row in range(1, 9):
            for col_idx in range(8):
                col = chr(ord('A') + col_idx)
                field = TChessField(str(row), col)
                self.fields[f"{col}{row}"] = field

    def tearDown(self):
        for field in self.fields.values():
            field.setBusy(None)
        self.all_pieces.clear()

    def clear_all_fields(self):
        for field in self.fields.values():
            field.setBusy(None)
        self.all_pieces.clear()

    def test_bishop_move_diagonal_up_right(self):
        self.clear_all_fields()
        field = self.fields["D4"]
        bishop = Bishop(ESide.WHITE, field)
        self.all_pieces.append(bishop)

        move = TChessMove(field, self.fields["F6"])
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_bishop_move_diagonal_up_left(self):
        self.clear_all_fields()
        field = self.fields["E5"]
        bishop = Bishop(ESide.WHITE, field)
        self.all_pieces.append(bishop)

        move = TChessMove(field, self.fields["B8"])
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_bishop_move_diagonal_down_right(self):
        self.clear_all_fields()
        field = self.fields["C6"]
        bishop = Bishop(ESide.WHITE, field)
        self.all_pieces.append(bishop)

        move = TChessMove(field, self.fields["E4"])
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_bishop_move_diagonal_down_left(self):
        self.clear_all_fields()
        field = self.fields["F7"]
        bishop = Bishop(ESide.WHITE, field)
        self.all_pieces.append(bishop)

        move = TChessMove(field, self.fields["C4"])
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_bishop_capture_enemy(self):
        self.clear_all_fields()
        from_field = self.fields["C1"]
        to_field = self.fields["F4"]

        bishop = Bishop(ESide.WHITE, from_field)
        self.all_pieces.append(bishop)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        enemy = DummyPiece(ESide.BLACK)
        to_field.setBusy(enemy)

        move = TChessMove(from_field, to_field)
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_bishop_move_to_edge(self):
        self.clear_all_fields()
        field = self.fields["D4"]
        bishop = Bishop(ESide.WHITE, field)
        self.all_pieces.append(bishop)

        move = TChessMove(field, self.fields["A1"])
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_bishop_move_max_distance(self):
        self.clear_all_fields()
        field = self.fields["A1"]
        bishop = Bishop(ESide.WHITE, field)
        self.all_pieces.append(bishop)

        move = TChessMove(field, self.fields["H8"])
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertTrue(result)

    def test_bishop_move_horizontal(self):
        self.clear_all_fields()
        field = self.fields["D4"]
        bishop = Bishop(ESide.WHITE, field)
        self.all_pieces.append(bishop)

        move = TChessMove(field, self.fields["H4"])
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertFalse(result)

    def test_bishop_move_vertical(self):
        self.clear_all_fields()
        field = self.fields["D4"]
        bishop = Bishop(ESide.WHITE, field)
        self.all_pieces.append(bishop)

        move = TChessMove(field, self.fields["D8"])
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertFalse(result)

    def test_bishop_move_through_own_piece(self):
        self.clear_all_fields()
        from_field = self.fields["C1"]
        to_field = self.fields["H6"]

        bishop = Bishop(ESide.WHITE, from_field)
        self.all_pieces.append(bishop)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        own = DummyPiece(ESide.WHITE)
        self.fields["F4"].setBusy(own)

        move = TChessMove(from_field, to_field)
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertFalse(result)

    def test_bishop_move_through_enemy_piece(self):
        self.clear_all_fields()
        from_field = self.fields["C1"]
        to_field = self.fields["H6"]

        bishop = Bishop(ESide.WHITE, from_field)
        self.all_pieces.append(bishop)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        enemy = DummyPiece(ESide.BLACK)
        self.fields["F4"].setBusy(enemy)

        move = TChessMove(from_field, to_field)
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertFalse(result)

    def test_bishop_capture_own(self):
        self.clear_all_fields()
        from_field = self.fields["C1"]
        to_field = self.fields["F4"]

        bishop = Bishop(ESide.WHITE, from_field)
        self.all_pieces.append(bishop)

        class DummyPiece:
            def __init__(self, side):
                self._side = side

            def getSide(self):
                return self._side

        own = DummyPiece(ESide.WHITE)
        to_field.setBusy(own)

        move = TChessMove(from_field, to_field)
        result = bishop.isValidMove(move, self.all_pieces, self.fields)
        self.assertFalse(result)

    def test_bishop_move_out_of_board(self):
        with self.assertRaises(ValueError):
            TChessField("9", "I")

    def test_bishop_initial_position(self):
        self.clear_all_fields()
        field = self.fields["C1"]
        bishop = Bishop(ESide.WHITE, field)

        self.assertEqual(bishop.getPosition(), field)
        self.assertEqual(bishop.getSide(), ESide.WHITE)
        self.assertEqual(bishop.getType(), EChessmanType.BISHOP)

    def test_bishop_as_string_notation(self):
        from_field = self.fields["C1"]
        to_field = self.fields["F4"]
        move = TChessMove(from_field, to_field, EChessmanType.BISHOP)
        self.assertEqual(move.asString(), "BC1-F4")

    def test_bishop_go_to_position(self):
        self.clear_all_fields()
        from_field = self.fields["C1"]
        to_field = self.fields["F4"]
        bishop = Bishop(ESide.WHITE, from_field)

        self.assertEqual(bishop.getPosition(), from_field)
        self.assertEqual(from_field.isBusy(), bishop)

        bishop.goToPosition(to_field)

        self.assertEqual(bishop.getPosition(), to_field)
        self.assertEqual(to_field.isBusy(), bishop)
        self.assertIsNone(from_field.isBusy())