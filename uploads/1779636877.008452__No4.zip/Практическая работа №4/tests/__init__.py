from .test_rook import TestRook
from .test_bishop import TestBishop
from .test_captures import TestCaptureScenarios

__all__ = ['TestRook', 'TestBishop', 'TestCaptureScenarios']