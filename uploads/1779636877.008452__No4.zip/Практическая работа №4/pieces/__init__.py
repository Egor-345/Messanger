from .rook import Rook
from .bishop import Bishop

__all__ = ['Rook', 'Bishop']