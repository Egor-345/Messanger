from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .chessman import TChessman


class TChessField:

    def __init__(self, row: str, col: str):
        if row not in [str(i) for i in range(1, 9)]:
            raise ValueError(f"Некорректная строка: {row}. Должна быть от 1 до 8")
        if col.upper() not in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']:
            raise ValueError(f"Некорректный столбец: {col}. Должен быть от A до H")

        self._row = row
        self._col = col.upper()
        self._busy: Optional['TChessman'] = None

    def getRow(self) -> str:
        return self._row

    def getCol(self) -> str:
        return self._col

    def isBusy(self) -> Optional['TChessman']:
        return self._busy

    def setBusy(self, piece: Optional['TChessman']):
        self._busy = piece

    def getRowInt(self) -> int:
        return int(self._row)

    def getColInt(self) -> int:
        return ord(self._col) - ord('A') + 1

    def __str__(self) -> str:
        return f"{self._col}{self._row}"

    def __eq__(self, other) -> bool:
        if not isinstance(other, TChessField):
            return False
        return self._row == other._row and self._col == other._col

    def __hash__(self):
        return hash((self._row, self._col))

    @classmethod
    def from_string(cls, coord: str) -> 'TChessField':
        if len(coord) != 2:
            raise ValueError(f"Некорректная координата: {coord}")
        col = coord[0].upper()
        row = coord[1]
        return cls(row, col)